﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace FileManager
{
    class Program
    {

        //Получение списка логических дисков Windows. Команда gld(get logical drives).
        static string[] getLogicalDrives()
        {
            string[] logicalDrives = Directory.GetLogicalDrives();
            for (int i = 0; i < logicalDrives.Length; i++)
                Console.WriteLine(logicalDrives[i]);
            return logicalDrives;
        }

        //Смена текущей папки на указанную. Команада cd(change dir).
        //сd C:\Users - перемещение по абсолютному пути.
        //cd users - перемещение по относительному пути.
        //cd .. - перемещение в родительскую дирректорию.
        //cd /(\) - перемещение в корневую дирректорию.
        static void changeDirectory(ref DirectoryInfo currDir, string path)
        {
            //Возвращение в родительскую дирректорию.
            if (path == "..")
            {
                if (currDir.Parent != null)
                    currDir = currDir.Parent;
                return;
            }

            //Возвращение в корневую дирректорию.
            if (path == "\\" || path == "/")
            {
                currDir = currDir.Root;
                return;
            }

            //Если в пути отсутствует символ ":", то путь является абсолютным.
            if (path.Contains(":") == false)
                path = currDir.ToString() + path;
            if (Directory.Exists(path) == false)
                throw new Exception("Указанная дирректория не найдена.");
            currDir = new DirectoryInfo(path);     
        }

        //Отображение папок и файлов в текущей дирректории.
        static void showDirsAndFiles(DirectoryInfo currDir)
        {
            DirectoryInfo[] dirs = currDir.GetDirectories();
            FileInfo[] files = currDir.GetFiles();
            for (int i = 0; i < dirs.Length; i++)
                Console.WriteLine(dirs[i]);
            for (int i = 0; i < files.Length; i++)
                Console.WriteLine(files[i]);
        }

        //Создание новой папки.
        static void makeDir(DirectoryInfo currDir, String name)
        {
            DirectoryInfo newDir = new DirectoryInfo(currDir + name);
            newDir.Create();
        }

        //Удаление папки с ее содержимым.
        static void removeDir(DirectoryInfo currDir, String name)
        {
            if (Directory.Exists(currDir.ToString() + name) == true)
                Directory.Delete(currDir.ToString() + name, true);
            else
                throw new Exception("Не удалось удалить указанную дирректорию. Указаанная дирректория не найдена.");
        }

        //Вызов программы
        static void callProgram(string path)
        {
            Process.Start(path);
        }

        //Вызов программы с агументами
        static void callProgram(string path, string args)
        {
            Process.Start(path, args);
        }

        //Копирование файла
        static void copyFile(string srcfn, string destfn)
        {
            FileInfo fn = new FileInfo(srcfn);
            fn.CopyTo(destfn, true);
        }

        //Копирование папки
        static void copyDir(string srcDir, string destDir)
        {
            if (Directory.Exists(srcDir) == false)
                throw new Exception("Не удалось скопировать дирректорию. Указанная директория не найдена.");
            Directory.CreateDirectory(destDir);
            foreach (string srcFile in Directory.GetFiles(srcDir))
            {
                string destFile = destDir + "\\" + Path.GetFileName(srcFile);
                File.Copy(srcFile, destFile);
            }
            foreach (string dir in Directory.GetDirectories(srcDir))
                copyDir(dir, destDir + "\\" + Path.GetFileName(dir));
        }
        static void processCommand(ref DirectoryInfo currDir, string command)
        {
            string[] partsCommand = command.Split(' ');
            partsCommand[0].ToLower();
            switch (partsCommand[0])
            {
                case "gld":
                    getLogicalDrives();
                    break;
                case "cd":
                    string path = "";
                    for (int i = 3; i < command.Length; i++)
                        path += command[i];
                    changeDirectory(ref currDir, path);
                    break;
                case "dir":
                    showDirsAndFiles(currDir);
                    break;
                case "md":
                    string dirName = "";
                    for (int i = 3; i < command.Length; i++)
                        dirName += command[i];
                    makeDir(currDir, dirName);
                    break;
                case "rd":
                    dirName = "";
                    for (int i = 3; i < command.Length; i++)
                        dirName += command[i];
                    removeDir(currDir, dirName);
                    break;
                case "start":
                    if (partsCommand.Length == 2)
                        callProgram(currDir + "\\" + partsCommand[1]);
                    else
                    {
                        string args = "";
                        for (int i = 2; i < partsCommand.Length; i++)
                            args += partsCommand[i];
                        callProgram(currDir + "\\" + partsCommand[1], args);
                    }
                    break;
                case "copy":
                    break;
                        
                default:
                    Console.WriteLine("Команда '" + partsCommand[0] + "' не найдена");
                    break;
            }

        }


        static void Main(string[] args)
        {
            DirectoryInfo currentDir = new DirectoryInfo(Directory.GetCurrentDirectory());
            while(true)
            {
                try
                {
                    Console.Write(currentDir.FullName + ">");
                    string command = Console.ReadLine();
                    processCommand(ref currentDir, command);
                }
                catch (Exception E)
                {
                    Console.WriteLine(E.Message);
                }
            }

        }
    }
}
